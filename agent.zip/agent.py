import sys
import os
import threading
import asyncio
import random

sys.path.append(os.path.dirname(__file__))

from dotenv import load_dotenv
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from threading import Thread

from livekit import agents
from livekit.agents import AgentSession, Agent, RoomInputOptions, function_tool, RunContext
from livekit.plugins import noise_cancellation
from livekit.plugins import google

from promts import AGENT_INSTRUCTION, SESSION_INSTRUCTION
from tools import (
    open_website,
    get_weather,
    open_default_browser,
    play_music,
    play_youtube_music,
    search_web,
    open_file_explorer,
)

load_dotenv()

# ---------------- Flask App ----------------
app = Flask(__name__, static_folder=".", static_url_path="")
CORS(app)

assistant_session = None
AI_READY = False


# ==================================================
# FRONTEND
# ==================================================

@app.route("/")
def home():
    return send_from_directory(".", "index.html")


# ==================================================
# ORIGINAL TOOLS (UNCHANGED)
# ==================================================

@function_tool()
async def check_weather(context: RunContext, city: str = "YourCity") -> str:
    from tools import DuckDuckGoSearchRun
    query = f"current temperature in {city}"
    result = DuckDuckGoSearchRun().run(tool_input=query)
    return f"The current weather in {city} is {result}."

@function_tool()
async def daily_reminder(context: RunContext) -> str:
    reminders = [
        "Don't forget to review your AI model today!",
        "Check your e-waste dataset for errors.",
        "Remember to test the agent's new function."
    ]
    return random.choice(reminders)

@function_tool()
async def open_learning_resource(context: RunContext, topic: str = "AI") -> str:
    resources = {
        "AI": "https://www.youtube.com/results?search_query=AI+tutorials",
        "Python": "https://www.python.org/doc/",
        "Machine Learning": "https://scikit-learn.org/stable/tutorial/index.html"
    }

    url = resources.get(topic, "https://www.google.com")

    import webbrowser
    webbrowser.open(url, new=2)

    return f"Opened resources for {topic}."

@function_tool()
async def create_project_folder(context: RunContext, name: str = "NewProject") -> str:
    path = os.path.join(os.getcwd(), name)

    if not os.path.exists(path):
        os.makedirs(path)
        return f"Project folder '{name}' created!"

    return f"Folder '{name}' already exists."

@function_tool()
async def motivate_user(context: RunContext) -> str:
    return random.choice([
        "You got this! Keep going!",
        "Every small step counts!",
        "Consistency is key!"
    ])

@function_tool()
async def find_file(context: RunContext, filename: str) -> str:
    matches = []

    for root, dirs, files in os.walk(os.getcwd()):
        if filename in files:
            matches.append(os.path.join(root, filename))

    return f"Found files: {matches}" if matches else "No files found."

@function_tool()
async def set_timer(context: RunContext, minutes: int = 1) -> str:

    def timer_done():
        print(f"\nTimer finished: {minutes} min")
        print("Wolf AI: Your timer is complete.\n")

    threading.Timer(minutes * 60, timer_done).start()

    return f"Timer set for {minutes} minute(s)."


# ==================================================
# IMPORTANT FUNCTION
# THIS PRINTS AI ANSWERS IN TERMINAL + VOICE
# ==================================================

async def ask_ai_and_print(user_text):
    global assistant_session

    result = await assistant_session.generate_reply(
        instructions=SESSION_INSTRUCTION,
        user_input=user_text
    )

    # PRINT TEXT ANSWER IN TERMINAL
    print(f"\nYou: {user_text}")
    print(f"Wolf AI: {result}\n")

    return result


# ==================================================
# TERMINAL CHAT MODE
# ==================================================

def terminal_chat():
    global AI_READY

    while True:

        if AI_READY:
            try:
                user_input = input("You: ")

                if user_input.lower() in ["exit", "quit", "bye"]:
                    print("Wolf AI: Goodbye!")
                    os._exit(0)

                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)

                loop.run_until_complete(
                    ask_ai_and_print(user_input)
                )

                loop.close()

            except Exception as e:
                print("Error:", e)


# ==================================================
# FLASK API
# ==================================================

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "ai_ready": AI_READY})


@app.route("/ask", methods=["POST"])
def ask():
    global AI_READY

    data = request.json
    user_message = data.get("message", "")

    if not AI_READY:
        return jsonify({"reply": "Wolf AI is starting... Please wait."})

    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        result = loop.run_until_complete(
            ask_ai_and_print(user_message)
        )

        loop.close()

        return jsonify({"reply": result})

    except Exception as e:
        return jsonify({"reply": str(e)})


# ==================================================
# AGENT CLASS
# ==================================================

class Assistant(Agent):
    def __init__(self, tools=None):
        super().__init__(
            instructions=AGENT_INSTRUCTION,
            llm=google.beta.realtime.RealtimeModel(
                voice="charon"
            ),
            tools=tools or [],
        )


# ==================================================
# LIVEKIT ENTRYPOINT
# ==================================================

async def entrypoint(ctx: agents.JobContext):
    global assistant_session, AI_READY

    tools = [
        open_default_browser,
        get_weather,
        open_website,
        play_music,
        play_youtube_music,
        search_web,
        open_file_explorer,

        check_weather,
        daily_reminder,
        open_learning_resource,
        create_project_folder,
        motivate_user,
        find_file,
        set_timer
    ]

    assistant = Assistant(tools=tools)

    session = AgentSession()
    assistant_session = session

    await session.start(
        room=ctx.room,
        agent=assistant,
        room_input_options=RoomInputOptions(
            video_enabled=False,
            noise_cancellation=noise_cancellation.BVC(),
        ),
    )

    await ctx.connect()

    AI_READY = True

    print("\n====================================")
    print("Wolf AI is Ready")
    print("Type your message below")
    print("Type exit to close")
    print("====================================\n")

    greeting = "Hi, I am Wolf AI. How can I help you?"

    await ask_ai_and_print(greeting)

    threading.Thread(target=terminal_chat, daemon=True).start()


# ==================================================
# FLASK RUN
# ==================================================

def start_flask():
    print("Flask running at http://127.0.0.1:5000")

    app.run(
        host="127.0.0.1",
        port=5000,
        debug=False,
        use_reloader=False
    )


# ==================================================
# MAIN
# ==================================================

if __name__ == "__main__":

    flask_thread = threading.Thread(target=start_flask)
    flask_thread.daemon = True
    flask_thread.start()

    if len(sys.argv) == 1:
        sys.argv.append("start")

    agents.cli.run_app(
        agents.WorkerOptions(
            entrypoint_fnc=entrypoint,
            port=0
        )
    )